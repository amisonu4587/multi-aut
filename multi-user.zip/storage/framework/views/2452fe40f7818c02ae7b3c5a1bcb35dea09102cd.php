<h1>User Dashboard</h1>

<a href="/logout">Logout</a>
<?php /**PATH E:\XAMPP 02-08-2022\htdocs\LARAVEL-8\multi-user\resources\views/user/dashboard.blade.php ENDPATH**/ ?>