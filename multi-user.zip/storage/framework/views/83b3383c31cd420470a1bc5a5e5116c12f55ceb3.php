<?php $__env->startSection('space-work'); ?>

    <h2 class="mb-4">Super Admin</h2>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP 02-08-2022\htdocs\LARAVEL-8\multi-user\resources\views/super-admin/dashboard.blade.php ENDPATH**/ ?>