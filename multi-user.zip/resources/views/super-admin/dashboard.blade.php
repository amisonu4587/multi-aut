@extends('layout/layout')

@section('space-work')

    <h2 class="mb-4">Super Admin</h2>

@endsection
